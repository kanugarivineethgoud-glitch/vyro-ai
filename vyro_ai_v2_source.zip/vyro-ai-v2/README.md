# VYRO AI Studio — Build 2.0

A dark creator-workspace MVP with:
- Public-facing responsive dashboard
- Local anime scene planner and short-form script outline builder
- Browser-local project library (localStorage)
- Local video preview and WebM clip export using MediaRecorder
- Optional server-side AI video generation adapter using fal.ai
- Rate limit, duration cap, per-request estimated cost cap, and generation disabled by default

## Run locally

1. Install Node.js 20+.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Run `npm start`.
5. Open `http://localhost:3000`.

## AI video integration

The generation endpoint is OFF by default. The template is wired to fal's JS client and a MiniMax H3 Max text-to-video endpoint. Before enabling:
- Check the selected model's current input/output schema and price.
- Set `FAL_KEY` only in the server `.env` (never in browser files).
- Set a conservative `MAX_VIDEO_SECONDS_PER_REQUEST` and `MAX_ESTIMATED_USD_PER_REQUEST`.
- Set `ENABLE_VIDEO_GENERATION=true` only after testing.
- Add authentication and per-user quotas before making generation available to the public.

The sample request uses `prompt`, `duration`, and `aspect_ratio`; provider schemas can change, so verify them against the current model page before production use.

## Important production gaps

This is a starter MVP, not a fully launched SaaS. Before public launch, add:
- Real account authentication, email verification, password reset and secure sessions
- Database-backed projects and user-specific storage
- Abuse prevention, per-user quotas, provider spend alerts and billing controls
- Terms, privacy notice, content moderation, reporting and takedown process
- Secure file upload limits, malware scanning and storage lifecycle rules
- Accessibility, browser/device testing, backups and monitoring

Do not collect children's personal data or open paid generation to the public without appropriate legal/privacy review and adult oversight. Keep the AI generation endpoint disabled until authentication and cost controls are in place.

## Current limitations

- Anime planner and script writer use local templates; they are not AI text generation.
- Clip export records playback in real time, producing WebM where supported. It is not a frame-accurate, professional multi-track editor.
- Projects are saved only in the current browser/device; clearing browser storage deletes them.

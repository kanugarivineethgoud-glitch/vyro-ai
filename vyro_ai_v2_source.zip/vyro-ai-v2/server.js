import "dotenv/config";
import express from "express";
import rateLimit from "express-rate-limit";
import { fal } from "@fal-ai/client";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const limiter = rateLimit({ windowMs: 60_000, limit: 5, standardHeaders: "draft-7", legacyHeaders: false });
const maxSeconds = Math.max(1, Math.min(10, Number(process.env.MAX_VIDEO_SECONDS_PER_REQUEST || 5)));
const maxCost = Math.max(0, Number(process.env.MAX_ESTIMATED_USD_PER_REQUEST || 0.25));
const unitCost = 0.05; // USD/sec based on the listed MiniMax H3 Max rate; re-check before enabling.

app.get("/api/status", (_req, res) => {
  res.json({
    generationEnabled: process.env.ENABLE_VIDEO_GENERATION === "true" && Boolean(process.env.FAL_KEY),
    maxSeconds,
    estimatedUsdPerSecond: unitCost,
    message: "Local editing and planning tools are available. AI generation requires server setup."
  });
});

app.post("/api/video/generate", limiter, async (req, res) => {
  if (process.env.ENABLE_VIDEO_GENERATION !== "true" || !process.env.FAL_KEY) {
    return res.status(503).json({ error: "AI video generation is not enabled on this server yet. Add a provider key, review costs, and enable it deliberately." });
  }
  const prompt = String(req.body?.prompt || "").trim();
  const seconds = Number(req.body?.seconds || 5);
  const aspect = String(req.body?.aspect || "9:16");
  if (prompt.length < 12 || prompt.length > 1500) return res.status(400).json({ error: "Prompt must be between 12 and 1,500 characters." });
  if (!Number.isFinite(seconds) || seconds < 1 || seconds > maxSeconds) return res.status(400).json({ error: `Choose a duration from 1 to ${maxSeconds} seconds.` });
  if (!["9:16","16:9","1:1"].includes(aspect)) return res.status(400).json({ error: "Unsupported aspect ratio." });
  const estimate = seconds * unitCost;
  if (estimate > maxCost) return res.status(400).json({ error: `Estimated cost $${estimate.toFixed(2)} exceeds this server's per-request cap.` });

  try {
    fal.config({ credentials: process.env.FAL_KEY });
    const result = await fal.subscribe(process.env.FAL_MODEL_ID || "fal-ai/minimax/h3-max/text-to-video", {
      input: { prompt, duration: seconds, aspect_ratio: aspect },
      logs: false
    });
    const videoUrl = result?.data?.video?.url || result?.video?.url;
    if (!videoUrl) return res.status(502).json({ error: "Provider returned no video URL. Check the selected model's input/output schema." });
    res.json({ videoUrl, estimatedCostUsd: estimate, requestId: result?.requestId || null });
  } catch (err) {
    console.error("Video provider error:", err?.message || err);
    res.status(502).json({ error: "Video provider request failed. Check server logs and the model's current API schema." });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`VYRO AI running at http://localhost:${port}`));
